# Hello website!

This is a basic HTML,css and Js starter project you can build on however you like. 
No need to save. While you develop your site, your changes will happen ✨ immediately in the preview window. On the left you'll see the files that make up your site, including HTML, JavaScript, and CSS. You can upload assets like images or audio in `assets`. The rest is up to you and your imagination. 🦄

_Last updated: 28 Feb 2023_

## What's in this project?

← `README.md`: That's this file, where you can tell people what your cool website does and how you built it.
a simple qr code generator using api